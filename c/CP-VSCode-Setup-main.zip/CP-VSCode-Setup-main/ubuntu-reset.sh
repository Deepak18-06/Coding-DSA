#!/bin/bash

#Copy Contents of Reset Folder into Current Folder
mkdir -p Current
cp -rf Reset/* Current/